package com.example.appfichaje

import android.content.Context
import androidx.room.*

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val pin: String,
    val role: String
)

@Entity(tableName = "punches")
data class PunchEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: String,
    val type: String,
    val timestamp: Long
)

@Dao
interface AppDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertUser(user: UserEntity)

    @Delete
    suspend fun deleteUser(user: UserEntity)

    @Query("SELECT * FROM users")
    suspend fun getAllUsers(): List<UserEntity>

    @Query("SELECT * FROM users WHERE id = :id AND pin = :pin LIMIT 1")
    suspend fun verifyUser(id: String, pin: String): UserEntity?

    @Insert
    suspend fun insertPunch(punch: PunchEntity)

    @Query("SELECT * FROM punches ORDER BY timestamp DESC")
    suspend fun getAllPunches(): List<PunchEntity>

    @Query("SELECT * FROM punches WHERE userId = :userId ORDER BY timestamp DESC")
    suspend fun getPunchesByUser(userId: String): List<PunchEntity>

    @Query("SELECT COUNT(*) FROM punches WHERE userId = :userId AND timestamp >= :startOfDay")
    suspend fun getPunchesToday(userId: String, startOfDay: Long): Int
}

@Database(entities = [UserEntity::class, PunchEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "fichaje_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}