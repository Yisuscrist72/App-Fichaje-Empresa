package com.example.appfichaje

// --- IMPORTS: Necesarios para UI, Navegación y Ciclo de Vida ---
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.*
import java.text.SimpleDateFormat
import java.util.*

// --- CONFIGURACIÓN VISUAL (Temas y Colores) ---
val PrimaryBlue = Color(0xFF1A237E)
val SuccessGreen = Color(0xFF2E7D32)
val ErrorRed = Color(0xFFC62828)
val BackgroundGray = Color(0xFFF5F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicialización de Base de Datos y ViewModel con Factory
        val db = AppDatabase.getDatabase(applicationContext)
        val factory = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T = AppViewModel(db.appDao()) as T
        }
        val viewModel: AppViewModel by viewModels { factory }

        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = PrimaryBlue)) {
                val user by viewModel.currentUser.collectAsState()
                Surface(color = BackgroundGray) {
                    // Si no hay usuario logueado, muestra Login; si no, la App principal
                    if (user == null) LoginScreen(viewModel) else AppScreen(viewModel, user!!)
                }
            }
        }
    }
}

// --- BLOQUE: PANTALLA DE LOGIN ---
@Composable
fun LoginScreen(v: AppViewModel) {
    var id by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    val msg by v.uiMessage.collectAsState()
    val ctx = LocalContext.current

    // Observador de mensajes (Toasts) para errores de login
    LaunchedEffect(msg) { msg?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); v.clearMessage() } }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(elevation = CardDefaults.cardElevation(8.dp), shape = RoundedCornerShape(24.dp)) {
            // CORRECCIÓN AQUÍ: Se eliminó el "as Arrangement.Vertical" y se usaron parámetros con nombre
            Column(
                modifier = Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.Lock, null, Modifier.size(64.dp), PrimaryBlue)
                Text("Control de Horarios", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(24.dp))

                OutlinedTextField(id, { id = it }, label = { Text("ID Usuario") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it },
                    label = { Text("PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(24.dp))

                Button({ v.login(id, pin) }, Modifier.fillMaxWidth().height(50.dp)) { Text("ENTRAR") }
            }
        }
    }
}

// --- BLOQUE: ESTRUCTURA PRINCIPAL (Navegación) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen(v: AppViewModel, user: UserEntity) {
    val nav = rememberNavController()
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Fichaje App", fontWeight = FontWeight.Bold) },
                actions = { IconButton({ v.logout() }) { Icon(Icons.Default.ExitToApp, null, tint = ErrorRed) } }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                val navBackStackEntry by nav.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                // Si es ADMIN ve 3 iconos, si es EMPLEADO solo 2
                val items = if (user.role == "ADMIN") listOf("fichaje", "historial", "usuarios") else listOf("fichaje", "historial")

                items.forEach { screen ->
                    NavigationBarItem(
                        selected = currentRoute == screen,
                        onClick = { nav.navigate(screen) { launchSingleTop = true } },
                        icon = {
                            Icon(when(screen) {
                                "fichaje" -> Icons.Default.CheckCircle
                                "historial" -> Icons.Default.List
                                else -> Icons.Default.Person
                            }, null)
                        },
                        label = { Text(screen.replaceFirstChar { it.uppercase() }) }
                    )
                }
            }
        }
    ) { p ->
        // Contenedor de las pantallas según la ruta seleccionada
        NavHost(nav, "fichaje", Modifier.padding(p)) {
            composable("fichaje") { FichajeScreen(v) }
            composable("historial") { HistorialScreen(v) }
            composable("usuarios") { UsuariosScreen(v) }
        }
    }
}

// --- BLOQUE: PANTALLA DE FICHAJE (Botón Circular) ---
@Composable
fun FichajeScreen(v: AppViewModel) {
    val next by v.nextPunchType.collectAsState()
    val color = if (next == "Entrada") SuccessGreen else ErrorRed

    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Turno actual: Esperando $next", color = Color.Gray)
        Spacer(Modifier.height(32.dp))

        // Botón grande de fichaje que cambia de color según el estado
        Button(
            onClick = { v.registerPunch() },
            Modifier.size(200.dp),
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = color)
        ) {
            Text(next.uppercase(), fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
    }
}

// --- BLOQUE: PANTALLA DE HISTORIAL (Lista Desplegable) ---
@Composable
fun HistorialScreen(v: AppViewModel) {
    val list by v.historial.collectAsState()
    // Agrupamos por usuario para que el Admin vea los registros ordenados
    val grouped = list.groupBy { it.userId }
    val df = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())

    Column(Modifier.padding(16.dp)) {
        Text("Historial por Empleado", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(grouped.keys.toList()) { userId ->
                var open by remember { mutableStateOf(false) }
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.clickable { open = !open }.padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                            Text("ID: $userId", fontWeight = FontWeight.Bold)
                            Icon(if(open) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null)
                        }
                        // Animación para mostrar/ocultar los fichajes de cada persona
                        AnimatedVisibility(visible = open) {
                            Column(Modifier.padding(top = 8.dp)) {
                                HorizontalDivider()
                                grouped[userId]?.forEach {
                                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), Arrangement.SpaceBetween) {
                                        Text(it.type, color = if(it.type=="Entrada") SuccessGreen else ErrorRed)
                                        Text(df.format(Date(it.timestamp)), color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- BLOQUE: GESTIÓN DE USUARIOS (Solo Admin) ---
@Composable
fun UsuariosScreen(v: AppViewModel) {
    val users by v.users.collectAsState()
    var id by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var isAdmin by remember { mutableStateOf(false) }

    Column(Modifier.padding(16.dp)) {
        Text("Añadir Personal", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Card(Modifier.padding(vertical = 8.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                OutlinedTextField(id, { id = it }, label = { Text("ID") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(pin, { pin = it }, label = { Text("PIN") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(isAdmin, { isAdmin = it })
                    Text("Es Administrador")
                }
                Button(
                    onClick = { v.addUser(id, pin, if(isAdmin) "ADMIN" else "EMPLEADO"); id=""; pin="" },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("GUARDAR NUEVO USUARIO")
                }
            }
        }

        // Lista inferior de usuarios existentes con opción de borrar
        LazyColumn {
            items(users) { u ->
                ListItem(
                    headlineContent = { Text(u.id) },
                    supportingContent = { Text("Rol: ${u.role}") },
                    trailingContent = {
                        // Impedir que el admin se borre a sí mismo por error
                        if(u.id != "admin") {
                            IconButton({ v.deleteUser(u) }) { Icon(Icons.Default.Delete, null, tint = ErrorRed) }
                        }
                    }
                )
            }
        }
    }
}