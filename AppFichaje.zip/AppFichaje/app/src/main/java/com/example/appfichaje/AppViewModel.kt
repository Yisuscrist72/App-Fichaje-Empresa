package com.example.appfichaje

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.util.Calendar

class AppViewModel(private val dao: AppDao) : ViewModel() {

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _users = MutableStateFlow<List<UserEntity>>(emptyList())
    val users: StateFlow<List<UserEntity>> = _users.asStateFlow()

    private val _historial = MutableStateFlow<List<PunchEntity>>(emptyList())
    val historial: StateFlow<List<PunchEntity>> = _historial.asStateFlow()

    private val _uiMessage = MutableStateFlow<String?>(null)
    val uiMessage: StateFlow<String?> = _uiMessage.asStateFlow()

    private val _nextPunchType = MutableStateFlow("Entrada")
    val nextPunchType: StateFlow<String> = _nextPunchType.asStateFlow()

    private var lastPunchTime: Long = 0

    init {
        viewModelScope.launch {
            if (dao.getAllUsers().isEmpty()) {
                dao.insertUser(UserEntity("admin", "1234".toHash(), "ADMIN"))
            }
        }
    }

    private fun String.toHash(): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(this.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun login(id: String, pin: String) {
        viewModelScope.launch {
            val user = dao.verifyUser(id, pin.toHash())
            if (user != null) {
                _currentUser.value = user
                loadHistorial()
                updateNextPunchType()
                if (user.role == "ADMIN") loadUsers()
            } else {
                _uiMessage.value = "ID o PIN incorrectos"
            }
        }
    }

    fun logout() { _currentUser.value = null }

    private fun updateNextPunchType() {
        viewModelScope.launch {
            val user = _currentUser.value ?: return@launch
            val startOfDay = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val punchesToday = dao.getPunchesToday(user.id, startOfDay)
            _nextPunchType.value = if (punchesToday % 2 == 0) "Entrada" else "Salida"
        }
    }

    fun loadUsers() { viewModelScope.launch { _users.value = dao.getAllUsers() } }

    fun addUser(id: String, pin: String, role: String) {
        viewModelScope.launch {
            if (id.isBlank() || pin.length !in 4..6) {
                _uiMessage.value = "PIN debe tener 4-6 dígitos"; return@launch
            }
            dao.insertUser(UserEntity(id, pin.toHash(), role))
            _uiMessage.value = "Usuario $id creado"
            loadUsers()
        }
    }

    fun deleteUser(user: UserEntity) {
        viewModelScope.launch {
            if (user.id == "admin") return@launch
            dao.deleteUser(user)
            loadUsers()
            _uiMessage.value = "Usuario eliminado"
        }
    }

    fun loadHistorial() {
        viewModelScope.launch {
            val user = _currentUser.value ?: return@launch
            _historial.value = if (user.role == "ADMIN") dao.getAllPunches() else dao.getPunchesByUser(user.id)
        }
    }

    fun registerPunch() {
        val now = System.currentTimeMillis()
        if (now - lastPunchTime < 2000) return
        lastPunchTime = now
        viewModelScope.launch {
            val user = _currentUser.value ?: return@launch
            val type = _nextPunchType.value
            dao.insertPunch(PunchEntity(userId = user.id, type = type, timestamp = now))
            _uiMessage.value = "$type registrada con éxito"
            loadHistorial()
            updateNextPunchType()
        }
    }

    fun clearMessage() { _uiMessage.value = null }
}